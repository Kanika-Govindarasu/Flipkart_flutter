class Product{
   String image;
   String productName;
   String price;

   Product({required this.image,required this.price,required this.productName});


}

